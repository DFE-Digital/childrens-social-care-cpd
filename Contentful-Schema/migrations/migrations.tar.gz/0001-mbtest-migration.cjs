module.exports = function (migration) {
    const contentType = migration.editContentType('aaa');
    contentType.createField('category')
      .name('Category')
      .type('Symbol');
  }