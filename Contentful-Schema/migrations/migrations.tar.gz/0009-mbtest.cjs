module.exports = function (migration) {
    const infoBox = migration
        .createContentType("mbtest1234")
        .name("mbtest1234")
        .description(
            "mbtest1234"
        )
        .displayField("title");

    infoBox
        .createField("title")
        .name("Title")
        .type("Symbol")
        .localized(false)
        .required(true)
        .validations([
            {
                unique: true,
            },
        ])
        .disabled(false)
        .omitted(false);
}