module.exports = function (migration) {
    const infoBox = migration
        .createContentType("infoBox")
        .name("Info Box")
        .description(
            "A text box with a light blue shaded background and an 'i' information icon in the top left corner. It is used to draw attention to a particular piece of text."
        )
        .displayField("title");

    infoBox
        .createField("title")
        .name("Title")
        .type("Symbol")
        .localized(false)
        .required(true)
        .validations([
            {
                unique: true,
            },
        ])
        .disabled(false)
        .omitted(false);
}